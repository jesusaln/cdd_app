<?php

return [
    // Métodos de pago que se marcan como 'recibido' automáticamente al crear la entrega
    'auto_recibido_metodos' => [
        'transferencia',
    ],
];

